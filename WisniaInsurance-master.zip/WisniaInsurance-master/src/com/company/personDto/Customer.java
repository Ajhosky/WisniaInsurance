package com.company.personDto;

public class Customer {
   protected Integer id;
   protected String name;
   protected String phoneNumber;
   protected Address address;

   public Customer(Integer id, String name, String phoneNumber, Address address) {
      this.id = id;
      this.name = name;
      this.phoneNumber = phoneNumber;
      this.address = address;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getPhoneNumber() {
      return phoneNumber;
   }

   public void setPhoneNumber(String phoneNumber) {
      this.phoneNumber = phoneNumber;
   }

   public Address getAddress() {
      return address;
   }

   public void setAddress(Address address) {
      this.address = address;
   }

   public static void addCustomer(){

   }
}

package com.company;

import com.company.events.Event;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Event.reportCase();
    }
}

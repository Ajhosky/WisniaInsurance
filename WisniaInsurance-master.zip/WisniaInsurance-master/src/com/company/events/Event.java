package com.company.events;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Event {
    protected Integer id;
    protected Date date;
    protected Damage damage;
    protected String process;
    protected String place;

    public Event(Integer id, Date date, Damage damage, String process, String place) {
        this.id = id;
        this.date = date;
        this.damage = damage;
        this.process = process;
        this.place = place;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Damage getDamage() {
        return damage;
    }

    public void setDamage(Damage damage) {
        this.damage = damage;
    }

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }
    public static void reportCase(){
        Scanner myObj = new Scanner(System.in);
        System.out.println("NA_OSOBIE, NA_MIENIU, NA_RZECZY");
        System.out.println("What is the application for?");
        String damageType = myObj.nextLine();
        if (damageType == "NA_OSOBIE"){

            System.out.println("Enter your policy number: ");
            Scanner readPolicyNumber = new Scanner(System.in);
            String policyNumber = readPolicyNumber.nextLine();
        }else if (damageType == "NA_MIENIU"){
            System.out.println("Enter your policy number: ");
            Scanner readPolicyNumber = new Scanner(System.in);
            String policyNumber = readPolicyNumber.nextLine();

        }else if (damageType == "NA_RZECZY"){
            System.out.println("Enter your policy number: ");
            Scanner readPolicyNumber = new Scanner(System.in);
            String policyNumber = readPolicyNumber.nextLine();

        }
    }
}

package com.company.personDto;

public class Company extends Customer {
    protected String NIP;
    protected String regon;
    protected Representative representative;

    public Company(Integer id, String name, String phoneNumber, Address address, String NIP, String regon, Representative representative) {
        super(id, name, phoneNumber, address);
        this.NIP = NIP;
        this.regon = regon;
        this.representative = representative;
    }

    public String getNIP() {
        return NIP;
    }

    public void setNIP(String NIP) {
        this.NIP = NIP;
    }

    public String getRegon() {
        return regon;
    }

    public void setRegon(String regon) {
        this.regon = regon;
    }

    public Representative getRepresentative() {
        return representative;
    }

    public void setRepresentative(Representative representative) {
        this.representative = representative;
    }
}

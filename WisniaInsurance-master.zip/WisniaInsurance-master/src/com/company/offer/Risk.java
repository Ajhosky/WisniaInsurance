package com.company.offer;

import java.util.Date;

public class Risk {
    protected Integer id;
    protected Float priceFrom;
    protected Float priceTo;
    protected String description;
    protected Date protectionFrom;
    protected Date protectionTo;
    protected PolicyType policyType;

    public Risk(Integer id, Float priceFrom, Float priceTo, String description, Date protectionFrom, Date protectionTo, PolicyType policyType) {
        this.id = id;
        this.priceFrom = priceFrom;
        this.priceTo = priceTo;
        this.description = description;
        this.protectionFrom = protectionFrom;
        this.protectionTo = protectionTo;
        this.policyType = policyType;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Float getPriceFrom() {
        return priceFrom;
    }

    public void setPriceFrom(Float priceFrom) {
        this.priceFrom = priceFrom;
    }

    public Float getPriceTo() {
        return priceTo;
    }

    public void setPriceTo(Float priceTo) {
        this.priceTo = priceTo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getProtectionFrom() {
        return protectionFrom;
    }

    public void setProtectionFrom(Date protectionFrom) {
        this.protectionFrom = protectionFrom;
    }

    public Date getProtectionTo() {
        return protectionTo;
    }

    public void setProtectionTo(Date protectionTo) {
        this.protectionTo = protectionTo;
    }

    public PolicyType getPolicyType() {
        return policyType;
    }

    public void setPolicyType(PolicyType policyType) {
        this.policyType = policyType;
    }

}

package com.company.personDto;

public class Address {
    protected String przedrostek;
    protected String zipCode;
    protected String country;
    protected String city;
    protected String street;

    public Address(String przedrostek, String zipCode, String country, String city, String street) {
        this.przedrostek = przedrostek;
        this.zipCode = zipCode;
        this.country = country;
        this.city = city;
        this.street = street;
    }

    public String getPrzedrostek() {
        return przedrostek;
    }

    public void setPrzedrostek(String przedrostek) {
        this.przedrostek = przedrostek;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }
}


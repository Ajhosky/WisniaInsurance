package com.company.offer;

import com.company.personDto.Customer;
import com.company.personDto.Person;

import java.util.Date;

public class Policy {
    protected Integer id;
    protected Customer policyHolder;
    protected Customer insured;
    protected Customer beneficiary;
    protected Risk risks;
    protected Date dateFrom;
    protected Date dateTo;
    protected float contributionPrice;
    protected PolicyType type;

    public Policy(Integer id, Person policyHolder, Person insured, Person beneficiary, Risk risks, Date dateFrom, Date dateTo, float contributionPrice, PolicyType type) {
        this.id = id;
        this.policyHolder = policyHolder;
        this.insured = insured;
        this.beneficiary = beneficiary;
        this.risks = risks;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
        this.contributionPrice = contributionPrice;
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Customer getPolicyHolder() {
        return policyHolder;
    }

    public void setPolicyHolder(Person policyHolder) {
        this.policyHolder = policyHolder;
    }

    public Customer getInsured() {
        return insured;
    }

    public void setInsured(Person insured) {
        this.insured = insured;
    }

    public Customer getBeneficiary() {
        return beneficiary;
    }

    public void setBeneficiary(Person beneficiary) {
        this.beneficiary = beneficiary;
    }

    public Risk getRisks() {
        return risks;
    }

    public void setRisks(Risk risks) {
        this.risks = risks;
    }

    public Date getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }

    public Date getDateTo() {
        return dateTo;
    }

    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }

    public float getContributionPrice() {
        return contributionPrice;
    }

    public void setContributionPrice(float contributionPrice) {
        this.contributionPrice = contributionPrice;
    }

    public PolicyType getType() {
        return type;
    }

    public void setType(PolicyType type) {
        this.type = type;
    }

    public static void createPolicy(){

    }
}

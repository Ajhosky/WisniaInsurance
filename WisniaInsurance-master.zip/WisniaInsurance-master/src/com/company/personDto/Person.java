package com.company.personDto;

public class Person extends Customer {
    protected String surname;
    protected String pesel;

    public Person(Integer id, String name, String phoneNumber, Address address, String surname, String pesel) {
        super(id, name, phoneNumber, address);
        this.surname = surname;
        this.pesel = pesel;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }
}


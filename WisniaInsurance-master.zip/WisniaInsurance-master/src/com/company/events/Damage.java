package com.company.events;

import com.company.offer.Policy;
import com.company.personDto.Person;

public class Damage {
    protected Integer id;
    protected Policy policy;
    protected DamageType damageType;
    protected String documents;
    protected Person victim;

    public Damage(Integer id, Policy policy, DamageType damageType, String documents, Person victim) {
        this.id = id;
        this.policy = policy;
        this.damageType = damageType;
        this.documents = documents;
        this.victim = victim;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Policy getPolicy() {
        return policy;
    }

    public void setPolicy(Policy policy) {
        this.policy = policy;
    }

    public DamageType getDamageType() {
        return damageType;
    }

    public void setDamageType(DamageType damageType) {
        this.damageType = damageType;
    }

    public String getDocuments() {
        return documents;
    }

    public void setDocuments(String documents) {
        this.documents = documents;
    }

    public Person getVictim() {
        return victim;
    }

    public void setVictim(Person victim) {
        this.victim = victim;
    }
}


package com.company.events;

public enum DamageType {
    NA_OSOBIE, NA_MIENIU, NA_RZECZY
}

package com.company.personDto;

import java.util.List;

public class Representative {
    protected String name;
    protected String surname;
    protected String phoneNumber;
    protected List<Company> companies;

    public Representative(String name, String surname, String phoneNumber, List<Company> companies) {
        this.name = name;
        this.surname = surname;
        this.phoneNumber = phoneNumber;
        this.companies = companies;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Company> getCompanies() {
        return companies;
    }

    public void setCompanies(List<Company> companies) {
        this.companies = companies;
    }
}
